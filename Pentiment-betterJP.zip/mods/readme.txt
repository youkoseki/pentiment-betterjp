Pentimentの日本語翻訳を改善するMODです。といっても、ただのテキストファイルです。

modsフォルダーごと、

ユーザーフォルダー（\\ユーザー\(自分のアカウント)\）以下の、

\AppData\LocalLow\Obsidian Entertainment\Pentiment\

の直下に置いてください。ゲームのプログラムのあるフォルダーではありません！

タイトル画面で「(MOD-vなんとか)」と表示されたら成功です。

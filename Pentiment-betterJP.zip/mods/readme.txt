Pentimentの翻訳改善MODです。といっても、ただのテキストファイルです。

modsフォルダーごと、

ユーザーフォルダー（\\ユーザー\(自分のアカウント)\）以下の、

\AppData\LocalLow\Obsidian Entertainment\Pentiment\

の直下に置いてください。ゲームのプログラムのあるフォルダーではありません！

タイトル画面で「オプション(MOD)」と表示されたら成功です。